chrome.devtools.panels.create(
    "API Insight",
    null,
    "index.html",
    null
);
