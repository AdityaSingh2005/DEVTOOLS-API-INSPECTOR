// Background service worker
console.log("DevTools API Inspector background worker started.");

// We can add listeners here if needed in the future
